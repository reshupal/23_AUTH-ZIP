const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", async function (event) {
  event.preventDefault();

  const email = document.getElementById("email").value;

  const password = document.getElementById("password").value;

  const message = document.getElementById("message");

  try {
    const response = await fetch("https://anilsoft.vercel.app/api/auth/login", {
      method: "POST",

      headers: {
        "Content-Type": "application/json",
      },

      body: JSON.stringify({
        email: email,
        password: password,
      }),
    });

    const data = await response.json();

    console.log(data);

    if (!response.ok) {
      throw new Error(data.message || "Login failed");
    }

    message.textContent = "Login successful!";

    message.style.color = "green";

    // Dashboard
    setTimeout(() => {
      window.location.href = "dashboard.html";
    }, 1000);
  } catch (error) {
    console.error(error);

    message.textContent = error.message;

    message.style.color = "red";
  }
});
